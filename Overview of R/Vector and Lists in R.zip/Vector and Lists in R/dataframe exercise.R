#creating dataframs
#assigning all the values from the right to d
d<-data.frame(col1=c(1,2,3), col2=c(-1,0,1))
#col3 is the sum of col2 and col1
d$col3<-d$col1+d$col2
print(d)

################end of exercise###################
